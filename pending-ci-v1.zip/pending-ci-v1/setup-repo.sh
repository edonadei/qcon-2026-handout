#!/usr/bin/env bash
# A repo with a bare "origin". $1 picks the scenario: blank | pr | pending-ci.
set -euo pipefail
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_NOSYSTEM=1
git init -q --bare ../origin.git
git init -q -b main && git config user.email dev@example.com && git config user.name Dev
git remote add origin ../origin.git
printf '# api\n\nThe HTTP client for our services.\n' > README.md
git add . && git commit -qm "Initial commit" && git push -q -u origin main
scenario="${1:-blank}"
if [[ "$scenario" == pending-ci ]]; then
  git rev-parse --verify 'refs/heads/main^{commit}' > ../pending-ci-main
fi
if [[ "$scenario" == pr || "$scenario" == pending-ci ]]; then
  git checkout -qb feature/retry-budget
  cat > http_client.py <<'PY'
import time


class RetryBudget:
    """Allow at most `limit` retries per `window` seconds, across all calls."""

    def __init__(self, limit: int, window: float, clock=time.monotonic):
        self.limit, self.window, self.clock = limit, window, clock
        self.spent: list[float] = []

    def try_spend(self) -> bool:
        now = self.clock()
        self.spent = [t for t in self.spent if now - t < self.window]
        if len(self.spent) >= self.limit:
            return False
        self.spent.append(now)
        return True
PY
  git add . && git commit -qm "Add a retry budget to the HTTP client" && git push -q -u origin feature/retry-budget
fi
