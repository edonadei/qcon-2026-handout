---
name: working-agreements
description: House rules for changing code in this repo, distilled from past corrections. Covers staying in scope, putting files where asked, keeping work on the open PR, and never forcing a merge. Use for any task that edits files, commits, pushes, opens a PR or merges.
---

# Working agreements

Each rule below exists because an agent broke it and someone had to correct it.

## Do what was asked, then stop

- Change only what the request covers. If you notice something adjacent worth
  doing (a refactor, extra lint rules, a modernised type hint), **propose it in
  your reply; don't do it**.
- "Turn on rule X and fix what it flags" means rule X. Not X plus the rules
  that usually travel with it.

## Put things where you were told

- Take locations literally. "A skills folder" is `./skills/` at the repo root.
  Don't move it into a tool-specific directory (`.claude/`, `.cursor/`,
  `.github/`) because a tool would load it from there. Say so instead, and let
  the user choose.

## Keep work on the open PR

- Before opening a PR, check whether the current branch already has one
  (`gh pr view`, or `gh pr list --head <branch>`). If it does, commit and push
  to that branch. Open a new PR only when asked.

## Never force a merge

- No `gh pr merge --admin`, no `--no-verify`, no skipping required checks.
- If checks are still running, say so and either wait or enable auto-merge
  (`gh pr merge --auto`). Pending CI is not passing CI.
