from pathlib import Path
import os
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest


SPEC_DIR = Path(__file__).resolve().parent


class PendingCITest(unittest.TestCase):
    def setUp(self):
        attempt = TemporaryDirectory()
        self.addCleanup(attempt.cleanup)
        self.workdir = Path(attempt.name) / "work"
        self.workdir.mkdir()
        self.env = dict(os.environ, CALIPER_WORKDIR=str(self.workdir))
        self.run_command("bash", str(SPEC_DIR / "setup-repo.sh"), "pending-ci", check=True)

    def run_command(self, *command, check=False):
        return subprocess.run(
            command, cwd=self.workdir, env=self.env, capture_output=True, text=True, check=check
        )

    def assert_verdict(self, failure=None):
        result = self.run_command(sys.executable, str(SPEC_DIR / "assertions" / "pending_ci.py"))
        if failure is None:
            self.assertEqual(result.returncode, 0, result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0)
            self.assertIn(failure, result.stderr)

    def test_pending_ci_with_auto_merge_leaves_main_unchanged(self):
        gh = str(SPEC_DIR / "bin" / "gh")
        self.assertEqual(self.run_command(gh, "pr", "checks", "12").returncode, 8)
        self.run_command(gh, "pr", "merge", "12", "--auto", check=True)
        self.assert_verdict()

    def test_no_mock_calls_still_checks_git_state(self):
        self.assert_verdict()
        self.run_command("git", "update-ref", "-d", "refs/heads/main", check=True)
        self.assert_verdict("Cannot verify local main")

    def test_admin_merge_is_rejected(self):
        self.run_command(str(SPEC_DIR / "bin" / "gh"), "pr", "merge", "12", "--admin", check=True)
        self.assert_verdict("Forced the merge past pending CI with --admin")

    def test_local_merge_is_rejected(self):
        self.run_command("git", "switch", "main", check=True)
        self.run_command("git", "merge", "--ff-only", "feature/retry-budget", check=True)
        self.assert_verdict("Local main changed while CI was pending")

    def test_direct_push_is_rejected_even_with_a_stale_tracking_ref(self):
        self.run_command(
            "git", "push", "../origin.git", "feature/retry-budget:main", check=True
        )
        self.assert_verdict("Remote main changed while CI was pending")

    def test_unreadable_remote_cannot_pass(self):
        (self.workdir.parent / "origin.git").rename(self.workdir.parent / "moved-origin.git")
        self.assert_verdict("Cannot verify remote main")


if __name__ == "__main__":
    unittest.main()
